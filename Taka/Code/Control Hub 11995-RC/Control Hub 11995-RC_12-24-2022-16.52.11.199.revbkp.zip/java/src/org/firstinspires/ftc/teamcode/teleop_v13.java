package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@TeleOp(name = "teleop_v13 (Blocks to Java)")
public class teleop_v13 extends LinearOpMode {

  private DcMotor frontright;
  private DcMotor backright;
  private DcMotor frontleft;
  private DcMotor backleft;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    double vertical;
    double horizontal;

    frontright = hardwareMap.get(DcMotor.class, "frontright");
    backright = hardwareMap.get(DcMotor.class, "backright");
    frontleft = hardwareMap.get(DcMotor.class, "frontleft");
    backleft = hardwareMap.get(DcMotor.class, "backleft");

    // Put initialization blocks here.
    frontright.setDirection(DcMotorSimple.Direction.REVERSE);
    backright.setDirection(DcMotorSimple.Direction.REVERSE);
    frontleft.setDirection(DcMotorSimple.Direction.REVERSE);
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        vertical = -(0.65 * gamepad1.left_stick_y);
        horizontal = 0.65 * gamepad1.left_stick_x;
        horizontal = 0.65 * gamepad1.right_stick_x;
        int pivot;
        pivot = -9;
        frontright.setPower(-pivot + (vertical - horizontal));
        backright.setPower(-pivot + vertical + horizontal);
        frontleft.setPower(pivot + vertical + horizontal);
        backleft.setPower(pivot + (vertical - horizontal));
        if (gamepad2.a) {
          frontleft.setPower(0.7);
        } else if (gamepad2.b) {
          frontright.setPower(-0.7);
        } else {
          backleft.setPower(0);
        }
        telemetry.update();
      }
    }
  }
}
