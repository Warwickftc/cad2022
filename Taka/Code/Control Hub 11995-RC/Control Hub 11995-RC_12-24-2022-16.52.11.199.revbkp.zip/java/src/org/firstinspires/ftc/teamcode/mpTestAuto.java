package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "mpTestAuto2 (Blocks to Java)", preselectTeleOp = "mpTest")
public class mpTestAuto extends LinearOpMode {

  private DcMotor LeftFront;
  private DcMotor RightFront;
  private DcMotor RightRear;
  private DcMotor LeftRear;

  /**
   * Stop and reset encoders on drive
   */
  private void ResetDriveEncoders() {
    LeftFront.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    LeftFront.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    LeftFront.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    LeftFront.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
  }

  /**
   * Turn Off All Motors
   */
  private void TurnOffMotors() {
    ((DcMotorEx) LeftFront).setVelocity(0);
    ((DcMotorEx) RightFront).setVelocity(0);
    ((DcMotorEx) RightRear).setVelocity(0);
    ((DcMotorEx) LeftRear).setVelocity(0);
  }

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    double v_RF;
    double v_LF;
    double v_LR;
    double v_RR;
    int AutoMode;
    ElapsedTime AutoTimer;
    double NR20_MaxVelocity;
    double NR20_PulsesPerInch;
    double NRC40_PulsesPerInch;
    double NRC40_MaxVelocity;
    double NRC40_PulsesPerDeg;
    double AutoDriveSpeed;
    double v_AutoDrive;
    double distance;

    LeftFront = hardwareMap.get(DcMotor.class, "LeftFront");
    RightFront = hardwareMap.get(DcMotor.class, "RightFront");
    RightRear = hardwareMap.get(DcMotor.class, "RightRear");
    LeftRear = hardwareMap.get(DcMotor.class, "LeftRear");

    // Set Motor parameters
    // am-3637b motprs 340 rpm (333/60 rps) encoder 7 pos per rev with 19.2 reduction
    // is 7*19,2 = 134.4 pulses per rev so max speed in
    // pps = 134.4 * 333.33 / 60 = 746,6 pulses per second max speed
    // We have 72 mm dia wheels so 1 rev propells us 72 * pi = 226 mm =
    // as we have xdrive the distance and speed in fwd/rev/left/right direction is multiplied with sqrt(2)
    // so we move fwd/left/right/rev by 320mm or 12.6 in
    // or to drive 1 inch in theory we need to go 134.4 / 12.6 = 10.667 pulses
    // To calculate the distance in inches its in*10,61 so for example 24 in is  254.64 Pulses
    NR20_MaxVelocity = 746.6;
    NR20_PulsesPerInch = 10.61;
    // Set Motor parameters for NRC40 (Neverrest Classic 40)
    // Same as NR40 as it uses same motor/encoder before the gearbox
    NRC40_MaxVelocity = 746.6;
    NRC40_PulsesPerInch = 22.1;
    // NRC40 does 7*40 = 280 pulses per deg so that gives 280/360 pulses per deg
    NRC40_PulsesPerDeg = 0.777777777778;
    // multiplier to get velocity in pps has to be <=1
    AutoDriveSpeed = 0.125;
    v_AutoDrive = AutoDriveSpeed * NRC40_MaxVelocity;
    LeftFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    LeftRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    RightFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    RightRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    LeftFront.setDirection(DcMotorSimple.Direction.REVERSE);
    RightFront.setDirection(DcMotorSimple.Direction.REVERSE);
    RightRear.setDirection(DcMotorSimple.Direction.REVERSE);
    LeftRear.setDirection(DcMotorSimple.Direction.REVERSE);
    LeftFront.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    RightFront.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    RightRear.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    LeftRear.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    // About +/- 1/6th inch
    ((DcMotorEx) LeftFront).setTargetPositionTolerance(2);
    ((DcMotorEx) RightFront).setTargetPositionTolerance(2);
    ((DcMotorEx) RightRear).setTargetPositionTolerance(2);
    ((DcMotorEx) LeftRear).setTargetPositionTolerance(2);
    TurnOffMotors();
    ResetDriveEncoders();
    v_RF = ((DcMotorEx) RightFront).getVelocity();
    v_LF = ((DcMotorEx) LeftFront).getVelocity();
    v_LR = ((DcMotorEx) LeftRear).getVelocity();
    v_RR = ((DcMotorEx) RightRear).getVelocity();
    AutoMode = 0;
    AutoTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    telemetry.addData("Status", "Auto Init 2");
    telemetry.update();
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        // Automode 0 = reset timer
        if (AutoMode == 0) {
          ResetDriveEncoders();
          AutoTimer.reset();
          AutoMode = 1;
        }
        // Automode 1 = Move fwd for  1000ms at speed .125
        if (AutoMode == 1) {
          telemetry.addData("Auto Mode", AutoMode);
          telemetry.addData("AutoDescription", "Move Fwd 12 in");
          telemetry.update();
          distance = NR20_PulsesPerInch * 12;
          LeftFront.setTargetPosition((int) distance);
          RightFront.setTargetPosition((int) -distance);
          RightRear.setTargetPosition((int) -distance);
          LeftRear.setTargetPosition((int) distance);
          ((DcMotorEx) LeftFront).setVelocity(v_AutoDrive);
          ((DcMotorEx) RightFront).setVelocity(v_AutoDrive);
          ((DcMotorEx) RightRear).setVelocity(v_AutoDrive);
          ((DcMotorEx) LeftRear).setVelocity(v_AutoDrive);
          // Give motors a little time
          sleep(250);
          // This way we ensure all motors are at destination
          while (LeftFront.isBusy() && RightFront.isBusy()) {
            sleep(250);
          }
          while (RightRear.isBusy() && LeftRear.isBusy()) {
            sleep(250);
          }
          ResetDriveEncoders();
          TurnOffMotors();
          AutoMode = 2;
        }
        if (AutoMode == 2) {
          telemetry.addData("Auto Mode", AutoMode);
          telemetry.addData("AutoDescription", "Move side ways 12 in");
          telemetry.update();
          ResetDriveEncoders();
          // Now lets move distance sideways
          distance = NR20_PulsesPerInch * 12;
          LeftFront.setTargetPosition((int) distance);
          RightFront.setTargetPosition((int) distance);
          RightRear.setTargetPosition((int) -distance);
          LeftRear.setTargetPosition((int) -distance);
          ((DcMotorEx) LeftFront).setVelocity(v_AutoDrive);
          ((DcMotorEx) RightFront).setVelocity(v_AutoDrive);
          ((DcMotorEx) RightRear).setVelocity(v_AutoDrive);
          ((DcMotorEx) LeftRear).setVelocity(v_AutoDrive);
          // Give motors a little time
          sleep(250);
          // This way we ensure all motors are at destination
          while (LeftFront.isBusy() && RightFront.isBusy()) {
            sleep(250);
          }
          while (RightRear.isBusy() && LeftRear.isBusy()) {
            sleep(250);
          }
          AutoMode = 3;
        }
      }
    }
  }
}
