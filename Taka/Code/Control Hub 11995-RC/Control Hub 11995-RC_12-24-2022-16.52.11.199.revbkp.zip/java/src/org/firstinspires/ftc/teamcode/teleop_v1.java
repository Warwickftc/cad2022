package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import java.lang.Math;

 @TeleOp(name = "teleop_v1 (Blocks to Java)")
 public class teleop_v1 extends LinearOpMode {

  private DcMotor frontright;
  private DcMotor backright;
  private DcMotor frontleft;
  private DcMotor backleft;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    double vertical;
    double horizontal;
    double pivot;
    double FR_v;
    double FL_v;
    double RL_v;
    double RR_v;
    double scale;

    frontright = hardwareMap.get(DcMotor.class, "FrontRight");
    backright = hardwareMap.get(DcMotor.class, "RearRight");
    frontleft = hardwareMap.get(DcMotor.class, "FrontLeft");
    backleft = hardwareMap.get(DcMotor.class, "RearLeft");

    // Put initialization blocks here.
    // 
    //backright.setDirection(DcMotorSimple.Direction.REVERSE);
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        vertical = -(0.65 * gamepad1.left_stick_y);
        horizontal = 0.65 * gamepad1.left_stick_x;
        pivot = 0.65 * gamepad1.right_stick_x;
        /*
          Table  Direction  FL   FR   RR   RL
                FWD vert     +   -    -    +
                Side Hor     +   +    -   -
        */
        FL_v = pivot + vertical + horizontal;
        FR_v = pivot - vertical + horizontal;
        RR_v = pivot - vertical - horizontal;
        RL_v = pivot + vertical - horizontal;
        scale = Math.max(Math.max(Math.abs(FL_v), Math.abs(FR_v)), Math.max(Math.abs(RR_v), Math.abs(RL_v)));
        
        if(scale > 1){
          FL_v = FL_v / scale;
          FR_v = FR_v / scale;
          RL_v = RL_v / scale;
          RR_v = RR_v / scale;
        }
        frontright.setPower(FR_v);
        backright.setPower(RR_v);
        frontleft.setPower(FL_v);
        backleft.setPower(RL_v);
        }
        telemetry.update();
      }
    }
  }
