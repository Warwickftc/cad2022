package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@TeleOp(name = "teleop_v1 (Blocks to Java)")
public class MecanumTeleOp extends LinearOpMode {

  private DcMotor frontright;
  private DcMotor backright;
  private DcMotor frontleft;
  private DcMotor backleft;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    double verticaly;
    double horizontaly;
    double verticalx;
    double horizontalx;

    frontright = hardwareMap.get(DcMotor.class, "frontright");
    backright = hardwareMap.get(DcMotor.class, "backright");
    frontleft = hardwareMap.get(DcMotor.class, "frontleft");
    backleft = hardwareMap.get(DcMotor.class, "backleft");

    // Put initialization blocks here.
    frontright.setDirection(DcMotorSimple.Direction.REVERSE);
    backright.setDirection(DcMotorSimple.Direction.REVERSE);
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        verticaly = (0.65 * gamepad1.left_stick_y);
        horizontaly = 0.65 * gamepad1.left_stick_x;
        verticalx = 0.65 * gamepad1.right_stick_y;
        horizontalx = 0.65 *gamepad1.right_stick_x;
        frontleft.setPower(verticaly);
        backright.setPower(verticaly);
        frontright.setPower(horizontaly);
        backleft.setPower(horizontaly);
        frontright.setPower(horizontalx);
        backleft.setPower(horizontalx);
        }
        telemetry.update();
      }
    }
  }
