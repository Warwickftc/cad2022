// IDENTIFIERS_USED=LeftFrontAsDcMotor,LeftRearAsDcMotor,RightFrontAsDcMotor,RightRearAsDcMotor

var delay, AutoTimer, AutoMode, tmo_str, NR20_MaxVelocity, NR20_PulsesPerInch, NRC40_MaxVelocity, NRC40_PulsesPerInch, NRC40_PulsesPerDeg, AutoDriveSpeed, v_AutoDrive, distance;

/**
 * Diwplay all pertinet info on the driverstations telemetry display
 */
function StatusUpdate(delay) {
  telemetry.addNumericData('Auto Mode', AutoMode);
  tmo_str = ['V: ',LeftFrontAsDcMotor.getVelocity(),'   P: ',miscAccess.roundDecimal(LeftFrontAsDcMotor.getPower(), 2),'   C: ',LeftFrontAsDcMotor.getCurrentPosition(),'   T: ',LeftFrontAsDcMotor.getTargetPosition(),'   B: ',RightFrontAsDcMotor.isBusy()].join('');
  telemetryAddTextData('LF', tmo_str);
  tmo_str = ['V: ',RightFrontAsDcMotor.getVelocity(),'   P: ',miscAccess.roundDecimal(RightFrontAsDcMotor.getPower(), 2),'   C: ',RightFrontAsDcMotor.getCurrentPosition(),'   T: ',RightFrontAsDcMotor.getTargetPosition(),'   B: ',RightFrontAsDcMotor.isBusy()].join('');
  telemetryAddTextData('RF', tmo_str);
  tmo_str = ['V: ',RightRearAsDcMotor.getVelocity(),'   P: ',miscAccess.roundDecimal(RightRearAsDcMotor.getPower(), 2),'   C: ',RightRearAsDcMotor.getCurrentPosition(),'   T: ',RightRearAsDcMotor.getTargetPosition(),'   B: ',RightRearAsDcMotor.isBusy()].join('');
  telemetryAddTextData('RR', tmo_str);
  tmo_str = ['V: ',LeftRearAsDcMotor.getVelocity(),'   P: ',miscAccess.roundDecimal(LeftRearAsDcMotor.getPower(), 2),'   C: ',LeftRearAsDcMotor.getCurrentPosition(),'   T: ',LeftRearAsDcMotor.getTargetPosition(),'   B: ',LeftRearAsDcMotor.isBusy()].join('');
  telemetryAddTextData('LR', tmo_str);
  telemetry.update();
  if (delay > 0) {
    linearOpMode.sleep(delay);
  }
}

/**
 * Stop and reset encoders on drive
 */
function ResetDriveEncoders() {
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  RightFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  RightRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  LeftRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
}

/**
 * Turn Off All Motors
 */
function TurnOffMotors() {
  LeftFrontAsDcMotor.setVelocity(0);
  RightFrontAsDcMotor.setVelocity(0);
  RightRearAsDcMotor.setVelocity(0);
  LeftRearAsDcMotor.setVelocity(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  NR20_MaxVelocity = 2500;
  NR20_PulsesPerInch = 49.3;
  // Same as NR40 as it uses same motor/encoder before the gearbox
  NRC40_MaxVelocity = 746.6;
  NRC40_PulsesPerInch = 22.1;
  // NRC40 does 7*40 = 280 pulses per deg so that gives 280/360 pulses per deg
  NRC40_PulsesPerDeg = 0.777777777778;
  // multiplier to get velocity in pps has to be <=1
  AutoDriveSpeed = 0.25;
  v_AutoDrive = AutoDriveSpeed * NR20_MaxVelocity;
  LeftFrontAsDcMotor.setDualMode("RUN_USING_ENCODER", LeftRearAsDcMotor, "RUN_USING_ENCODER");
  RightFrontAsDcMotor.setDualMode("RUN_USING_ENCODER", RightRearAsDcMotor, "RUN_USING_ENCODER");
  LeftFrontAsDcMotor.setDirection("REVERSE");
  RightFrontAsDcMotor.setDirection("REVERSE");
  RightRearAsDcMotor.setDirection("REVERSE");
  LeftRearAsDcMotor.setDirection("REVERSE");
  LeftFrontAsDcMotor.setZeroPowerBehavior("BRAKE");
  RightFrontAsDcMotor.setZeroPowerBehavior("BRAKE");
  RightRearAsDcMotor.setZeroPowerBehavior("BRAKE");
  LeftRearAsDcMotor.setZeroPowerBehavior("BRAKE");
  // About +/- 1/6th inch
  LeftFrontAsDcMotor.setTargetPositionTolerance(2);
  RightFrontAsDcMotor.setTargetPositionTolerance(2);
  RightRearAsDcMotor.setTargetPositionTolerance(2);
  LeftRearAsDcMotor.setTargetPositionTolerance(2);
  TurnOffMotors();
  ResetDriveEncoders();
  AutoMode = 0;
  AutoTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  telemetryAddTextData('Status', 'Auto Init 2');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      StatusUpdate(250);
      if (AutoMode == 0) {
        ResetDriveEncoders();
        elapsedTimeAccess.reset(AutoTimer);
        AutoMode = 1;
      }
      if (AutoMode == 1) {
        distance = NR20_PulsesPerInch * 36;
        LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
        RightFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
        RightRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
        LeftRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
        LeftFrontAsDcMotor.setTargetPosition(distance);
        RightFrontAsDcMotor.setTargetPosition(-distance);
        RightRearAsDcMotor.setTargetPosition(-distance);
        LeftRearAsDcMotor.setTargetPosition(distance);
        LeftFrontAsDcMotor.setMode("RUN_TO_POSITION");
        RightFrontAsDcMotor.setMode("RUN_TO_POSITION");
        RightRearAsDcMotor.setMode("RUN_TO_POSITION");
        LeftRearAsDcMotor.setMode("RUN_TO_POSITION");
        LeftFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightRearAsDcMotor.setVelocity(v_AutoDrive);
        LeftRearAsDcMotor.setVelocity(v_AutoDrive);
        // This way we ensure all motors are at destination
        while (LeftFrontAsDcMotor.isBusy() && RightFrontAsDcMotor.isBusy() && RightRearAsDcMotor.isBusy() && LeftRearAsDcMotor.isBusy()) {
          StatusUpdate(250);
        }
        AutoMode = 2;
        StatusUpdate(250);
      }
    }
  }
}
