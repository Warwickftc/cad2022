// IDENTIFIERS_USED=gamepad1,gamepad2,LeftFrontAsDcMotor,LeftRearAsDcMotor,RightFrontAsDcMotor,RightRearAsDcMotor

var maxAcceleration, js1_X, js1_Twist, Js1_Y, v_LF, v_RF, v_RR, v_LR, scale, elapsedTime;

/**
 * Routine to display telemetry on screen
 */
function teleopR_Telemetry() {
  telemetryAddTextData('Status', 'Running');
  telemetry.addNumericData('Left Front', LeftFrontAsDcMotor.getPower());
  telemetry.addNumericData('Right Fromt', RightFrontAsDcMotor.getPower());
  telemetry.addNumericData('Right Rear', RightRearAsDcMotor.getPower());
  telemetry.addNumericData('Left Rear', LeftRearAsDcMotor.getPower());
  telemetry.addNumericData('JS 1 X', gamepad1.getLeftStickX());
  telemetry.addNumericData('JS 1 Y', gamepad1.getLeftStickY());
  telemetry.addNumericData('JS 2 X', gamepad2.getLeftStickX());
  telemetry.update();
}

/**
 * Handle Xdrive related stuff here
 */
function teleop_XDrive(maxAcceleration) {
  js1_X = -gamepad1.getLeftStickX();
  js1_Twist = -gamepad1.getRightStickX();
  Js1_Y = gamepad1.getLeftStickY();
  v_LF = js1_Twist + Js1_Y;
  v_LF = v_LF + js1_X;
  v_RF = js1_Twist - Js1_Y;
  v_RF = v_RF + js1_X;
  v_RR = js1_Twist - Js1_Y;
  v_RR = v_RR - js1_X;
  v_LR = js1_Twist + Js1_Y;
  v_LR = v_LR - js1_X;
  scale = 1;
  if (Math.abs(v_LF) > scale) {
    scale = Math.abs(v_LF);
  }
  if (Math.abs(v_RF) > scale) {
    scale = Math.abs(v_RF);
  }
  if (Math.abs(v_LR) > scale) {
    scale = Math.abs(v_LR);
  }
  if (Math.abs(v_RR) > scale) {
    scale = Math.abs(v_RR);
  }
  if (scale > 1) {
    v_LF = v_LF / scale;
    v_RF = v_RF / scale;
    v_LR = v_LR / scale;
    v_RR = v_RR / scale;
  }
  LeftFrontAsDcMotor.setPower(v_LF);
  LeftRearAsDcMotor.setPower(v_LR);
  RightFrontAsDcMotor.setPower(v_RF);
  RightRearAsDcMotor.setPower(v_RR);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  LeftFrontAsDcMotor.setDirection("FORWARD");
  LeftRearAsDcMotor.setDirection("FORWARD");
  RightFrontAsDcMotor.setDirection("FORWARD");
  RightRearAsDcMotor.setDirection("FORWARD");
  LeftFrontAsDcMotor.setMode("RUN_USING_ENCODER");
  LeftRearAsDcMotor.setMode("RUN_USING_ENCODER");
  RightFrontAsDcMotor.setMode("RUN_USING_ENCODER");
  RightRearAsDcMotor.setMode("RUN_USING_ENCODER");
  telemetryAddTextData('Status', 'Init');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    elapsedTime = elapsedTimeAccess.create_withResolution("MILLISECONDS");
    elapsedTimeAccess.reset(elapsedTime);
    while (linearOpMode.opModeIsActive()) {
      teleop_XDrive(2.5);
      teleopR_Telemetry();
    }
  }
}
