/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  frontrightAsDcMotor.setDirection("REVERSE");
  backrightAsDcMotor.setDirection("REVERSE");
  duckAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    servoAsServo.setPosition(0.175);
    linearOpMode.sleep(10);
    linearOpMode.sleep(100);
    frontrightAsDcMotor.setDualPower(-0.65, backrightAsDcMotor, 0.65);
    frontleftAsDcMotor.setDualPower(0.65, backleftAsDcMotor, -0.65);
    linearOpMode.sleep(1100);
    frontrightAsDcMotor.setDualPower(0, backrightAsDcMotor, 0);
    frontleftAsDcMotor.setDualPower(0, backleftAsDcMotor, 0);
    linearOpMode.sleep(1000);
    servoAsServo.setPosition(0.3);
    linearOpMode.sleep(250);
    frontrightAsDcMotor.setDualPower(0.65, backrightAsDcMotor, -0.65);
    frontleftAsDcMotor.setDualPower(-0.65, backleftAsDcMotor, 0.65);
    linearOpMode.sleep(100);
    frontrightAsDcMotor.setDualPower(0, backrightAsDcMotor, 0);
    frontleftAsDcMotor.setDualPower(0, backleftAsDcMotor, 0);
    linearOpMode.sleep(1000);
    frontrightAsDcMotor.setDualPower(0.65, backrightAsDcMotor, 0.65);
    frontleftAsDcMotor.setDualPower(0.65, backleftAsDcMotor, 0.65);
    linearOpMode.sleep(2000);
    frontrightAsDcMotor.setDualPower(0, backrightAsDcMotor, 0);
    frontleftAsDcMotor.setDualPower(0, backleftAsDcMotor, 0);
  }
}
