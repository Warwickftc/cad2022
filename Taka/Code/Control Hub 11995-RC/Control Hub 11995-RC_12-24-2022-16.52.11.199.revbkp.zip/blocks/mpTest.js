// IDENTIFIERS_USED=gamepad1,LeftFrontAsDcMotor,LeftRearAsDcMotor,RightFrontAsDcMotor,RightRearAsDcMotor,Servo_RAsServo

var maxAcceleration, Js1_Y, Direction, Distance, v_Speed, t_Current, js1_X, curr_MaxPos, lpos_LF, nerror, js1_Twist, lpos_RF, pulseDistance, el_Time, lpos_RR, t_LastTelemetry, lpos_LR, NR20_TicsPerInch, v_LF, c_dir, LastError, v_RF, l_dir, txt_tmp, NR20_maxvelocity, v_RR, v_LR, scale, diff_LF, diff_RF, diff_RR, diff_LR, t_Last, diff_time;

/**
 * Routine to display telemetry on screen
 */
function teleopR_Telemetry() {
  // Lets only update the display 4x a sec at this time
  if (t_LastTelemetry + 250 <= t_Current) {
    telemetryAddTextData('Status', ['Running ',miscAccess.formatNumber(elapsedTimeAccess.getTime(el_Time), 2),' ms'].join(''));
    telemetryAddTextData('LF', ['V: ',miscAccess.roundDecimal(LeftFrontAsDcMotor.getVelocity(), 2),' P: ',miscAccess.roundDecimal(LeftFrontAsDcMotor.getPower(), 2),' C: ',miscAccess.roundDecimal(LeftFrontAsDcMotor.getCurrentPosition(), 2),' T: ',miscAccess.roundDecimal(LeftFrontAsDcMotor.getTargetPosition(), 2),' B: ',LeftFrontAsDcMotor.isBusy()].join(''));
    telemetryAddTextData('RF', ['V: ',miscAccess.roundDecimal(RightFrontAsDcMotor.getVelocity(), 2),' P: ',miscAccess.roundDecimal(RightFrontAsDcMotor.getPower(), 2),' C: ',miscAccess.roundDecimal(RightFrontAsDcMotor.getCurrentPosition(), 2),' T: ',miscAccess.roundDecimal(RightFrontAsDcMotor.getTargetPosition(), 2),' B: ',RightFrontAsDcMotor.isBusy()].join(''));
    telemetryAddTextData('RR', ['V: ',miscAccess.roundDecimal(RightRearAsDcMotor.getVelocity(), 2),' P: ',miscAccess.roundDecimal(RightRearAsDcMotor.getPower(), 2),' C: ',miscAccess.roundDecimal(RightRearAsDcMotor.getCurrentPosition(), 2),' T: ',miscAccess.roundDecimal(RightRearAsDcMotor.getTargetPosition(), 2),' B: ',RightRearAsDcMotor.isBusy()].join(''));
    telemetryAddTextData('LR', ['V: ',miscAccess.roundDecimal(LeftRearAsDcMotor.getVelocity(), 2),' P: ',miscAccess.roundDecimal(LeftRearAsDcMotor.getPower(), 2),' C: ',miscAccess.roundDecimal(LeftRearAsDcMotor.getCurrentPosition(), 2),' T: ',miscAccess.roundDecimal(LeftRearAsDcMotor.getTargetPosition(), 2),' B: ',LeftRearAsDcMotor.isBusy()].join(''));
    telemetryAddTextData('GPad1', ['LX: ',miscAccess.formatNumber(gamepad1.getLeftStickX(), 2),' LY: ',miscAccess.formatNumber(gamepad1.getLeftStickY(), 2),' RX: ',miscAccess.formatNumber(gamepad1.getRightStickX(), 2),' RY: ',miscAccess.formatNumber(gamepad1.getRightStickY(), 2)].join(''));
    txt_tmp = 0;
    telemetryAddTextData('DP1', ['DU: ',gamepad1.getDpadUp(),' DD: ',gamepad1.getDpadDown(),' DL: ',gamepad1.getDpadLeft(),' DR: ',gamepad1.getDpadRight()].join(''));
    telemetryAddTextData('Direction', l_dir);
    telemetry.update();
    t_LastTelemetry = elapsedTimeAccess.getTime(el_Time);
    t_Current = elapsedTimeAccess.getTime(el_Time);
  }
}

/**
 * Handle Xdrive related stuff here
 */
function teleop_XDrive(maxAcceleration) {
  t_Current = elapsedTimeAccess.getTime(el_Time);
  js1_X = gamepad1.getLeftStickX();
  js1_Twist = -gamepad1.getRightStickX();
  Js1_Y = gamepad1.getLeftStickY();
  v_LF = js1_Twist + 1;
  v_LF = v_LF + js1_X;
  v_RF = js1_Twist - Js1_Y;
  v_RF = v_RF + js1_X;
  v_RR = js1_Twist - Js1_Y;
  v_RR = v_RR - js1_X;
  v_LR = js1_Twist + Js1_Y;
  v_LR = v_LR - js1_X;
  scale = 1;
  if (Math.abs(v_LF) > scale) {
    scale = Math.abs(v_LF);
  }
  if (Math.abs(v_RF) > scale) {
    scale = Math.abs(v_RF);
  }
  if (Math.abs(v_LR) > scale) {
    scale = Math.abs(v_LR);
  }
  if (scale > 1) {
    v_LF = v_LF / scale;
    v_RF = v_RF / scale;
    v_LR = v_LR / scale;
    v_RR = v_RR / scale;
  }
  LeftFrontAsDcMotor.setPower(v_LF);
  LeftRearAsDcMotor.setPower(v_LR);
  RightFrontAsDcMotor.setPower(v_RF);
  RightRearAsDcMotor.setPower(v_RR);
  if (Math.abs(v_RR) > scale) {
    scale = Math.abs(v_RR);
  }
}

/**
 * We only go straught fwd and reverse or sideways
 * or twist and not a combination of them.
 * This is to adapt better to the grid behavior with all the obstacles
 * Furthermore teleop_XDrive is just a lasdjustmentst resort to do a
 */
function Xdrive_onedirection() {
  // + = Right - = Left
  js1_X = -gamepad1.getLeftStickX();
  js1_Twist = -gamepad1.getRightStickX();
  // - = Fwd + = Bacl
  Js1_Y = gamepad1.getLeftStickY();
  // We only drive if any value != 0
  if (js1_X != 0 || Js1_Y != 0 || js1_Twist != 0) {
    if (Math.abs(js1_X) > Math.abs(Js1_Y) && Math.abs(js1_X) > Math.abs(js1_Twist)) {
      Js1_Y = 0;
      js1_Twist = 0;
      if (js1_X > 0) {
        // Set Direction to "N"
        c_dir = 'L';
      } else {
        // Set Direction to "N"
        c_dir = 'R';
      }
    } else if (Math.abs(Js1_Y) > Math.abs(js1_Twist)) {
      js1_X = 0;
      js1_Twist = 0;
      if (Js1_Y > 0) {
        // Set Direction to "N"
        c_dir = 'B';
      } else {
        // Set Direction to "N"
        c_dir = 'F';
      }
    } else {
      js1_X = 0;
      Js1_Y = 0;
      if (js1_Twist > 0) {
        // Set Direction to "N"
        c_dir = '<';
      } else {
        // Set Direction to "N"
        c_dir = '>';
      }
    }
    v_LF = js1_Twist + Js1_Y;
    v_LF = v_LF + js1_X;
    v_RF = js1_Twist - Js1_Y;
    v_RF = v_RF + js1_X;
    v_RR = js1_Twist - Js1_Y;
    v_RR = v_RR - js1_X;
    v_LR = js1_Twist + Js1_Y;
    v_LR = v_LR - js1_X;
    LeftFrontAsDcMotor.setVelocity(v_LF * NR20_maxvelocity);
    RightFrontAsDcMotor.setVelocity(v_RF * NR20_maxvelocity);
    RightRearAsDcMotor.setVelocity(v_RR * NR20_maxvelocity);
    LeftRearAsDcMotor.setVelocity(v_LR * NR20_maxvelocity);
  } else {
    // Set Direction to "N"
    c_dir = 'N';
    LeftFrontAsDcMotor.setVelocity(0);
    RightFrontAsDcMotor.setVelocity(0);
    RightRearAsDcMotor.setVelocity(0);
    LeftRearAsDcMotor.setVelocity(0);
  }
  if (l_dir != c_dir && l_dir != 'N') {
    DriveAdjustPos();
  }
  // Set Direction to "N"
  l_dir = c_dir;
}

/**
 * Describe this function...
 */
function DriveAdjustPos() {
  curr_MaxPos = Math.abs(LeftFrontAsDcMotor.getCurrentPosition());
  if (curr_MaxPos < Math.abs(RightFrontAsDcMotor.getCurrentPosition())) {
    curr_MaxPos = Math.abs(RightFrontAsDcMotor.getCurrentPosition());
  }
  if (curr_MaxPos < Math.abs(RightRearAsDcMotor.getCurrentPosition())) {
    curr_MaxPos = Math.abs(RightRearAsDcMotor.getCurrentPosition());
  }
  if (curr_MaxPos < Math.abs(LeftRearAsDcMotor.getCurrentPosition())) {
    curr_MaxPos = Math.abs(LeftRearAsDcMotor.getCurrentPosition());
  }
  if (LeftFrontAsDcMotor.getCurrentPosition() < 0) {
    LeftFrontAsDcMotor.setTargetPosition(-curr_MaxPos);
  } else {
    LeftFrontAsDcMotor.setTargetPosition(curr_MaxPos);
  }
  if (RightFrontAsDcMotor.getCurrentPosition() < 0) {
    RightFrontAsDcMotor.setTargetPosition(-curr_MaxPos);
  } else {
    RightFrontAsDcMotor.setTargetPosition(curr_MaxPos);
  }
  if (RightRearAsDcMotor.getCurrentPosition() < 0) {
    RightRearAsDcMotor.setTargetPosition(-curr_MaxPos);
  } else {
    RightRearAsDcMotor.setTargetPosition(curr_MaxPos);
  }
  if (LeftRearAsDcMotor.getCurrentPosition() < 0) {
    LeftRearAsDcMotor.setTargetPosition(-curr_MaxPos);
  } else {
    LeftRearAsDcMotor.setTargetPosition(curr_MaxPos);
  }
  // Drive to target at 1/2 speed
  DriveToTargetPos(NR20_maxvelocity * 0.5);
}

/**
 * Stop all motors and set encoders to 0
 */
function StopAndZeroDriveEnc() {
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  RightFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  RightRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  LeftRearAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  Get_lpos();
}

/**
 * Get The last position used with l_dir to do error handling
 */
function Get_lpos() {
  lpos_LF = LeftFrontAsDcMotor.getCurrentPosition();
  lpos_RF = RightFrontAsDcMotor.getCurrentPosition();
  lpos_RR = RightRearAsDcMotor.getCurrentPosition();
  lpos_LR = LeftRearAsDcMotor.getCurrentPosition();
}

/**
 * Describe this function...Move a direction in Inches
 * Directuion F - B - L - R
 * Distance in inches
 */
function MoveDirInches(Direction, Distance) {
  nerror = 0;
  pulseDistance = NR20_TicsPerInch * Distance;
  StopAndZeroDriveEnc();
  if (Direction == 'B') {
    LeftFrontAsDcMotor.setTargetPosition(pulseDistance);
    RightFrontAsDcMotor.setTargetPosition(-pulseDistance);
    RightRearAsDcMotor.setTargetPosition(-pulseDistance);
    LeftRearAsDcMotor.setTargetPosition(pulseDistance);
  } else if (Direction == 'F') {
    LeftFrontAsDcMotor.setTargetPosition(-pulseDistance);
    RightFrontAsDcMotor.setTargetPosition(pulseDistance);
    RightRearAsDcMotor.setTargetPosition(pulseDistance);
    LeftRearAsDcMotor.setTargetPosition(-pulseDistance);
  } else if (Direction == 'L') {
    LeftFrontAsDcMotor.setTargetPosition(pulseDistance);
    RightFrontAsDcMotor.setTargetPosition(pulseDistance);
    RightRearAsDcMotor.setTargetPosition(-pulseDistance);
    LeftRearAsDcMotor.setTargetPosition(-pulseDistance);
  } else if (Direction == 'R') {
    LeftFrontAsDcMotor.setTargetPosition(-pulseDistance);
    RightFrontAsDcMotor.setTargetPosition(-pulseDistance);
    RightRearAsDcMotor.setTargetPosition(pulseDistance);
    LeftRearAsDcMotor.setTargetPosition(pulseDistance);
  } else {
    nerror = 1;
    LastError = 'MoveDirInches - Invalid command - ' + String(Direction);
  }
  // If there is no error drive to target
  if (nerror == 0) {
    // Drive to target at 1/2 speed
    DriveToTargetPos(NR20_maxvelocity * 0.5);
  }
}

/**
 * Describe this function...
 */
function DriveToTargetPos(v_Speed) {
  LeftFrontAsDcMotor.setMode("RUN_TO_POSITION");
  RightFrontAsDcMotor.setMode("RUN_TO_POSITION");
  RightRearAsDcMotor.setMode("RUN_TO_POSITION");
  LeftRearAsDcMotor.setMode("RUN_TO_POSITION");
  LeftFrontAsDcMotor.setVelocity(v_Speed);
  RightFrontAsDcMotor.setVelocity(v_Speed);
  RightRearAsDcMotor.setVelocity(v_Speed);
  LeftRearAsDcMotor.setVelocity(v_Speed);
  while (LeftFrontAsDcMotor.isBusy() || RightFrontAsDcMotor.isBusy() || RightRearAsDcMotor.isBusy() || LeftRearAsDcMotor.isBusy()) {
    teleopR_Telemetry();
    linearOpMode.sleep(20);
  }
  StopAndZeroDriveEnc();
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  Servo_RAsServo.setPosition(0);
  LeftFrontAsDcMotor.setDirection("FORWARD");
  LeftRearAsDcMotor.setDirection("FORWARD");
  RightFrontAsDcMotor.setDirection("FORWARD");
  RightRearAsDcMotor.setDirection("FORWARD");
  LeftFrontAsDcMotor.setMode("RUN_USING_ENCODER");
  LeftRearAsDcMotor.setMode("RUN_USING_ENCODER");
  RightFrontAsDcMotor.setMode("RUN_USING_ENCODER");
  RightRearAsDcMotor.setMode("RUN_USING_ENCODER");
  LeftFrontAsDcMotor.setTargetPositionTolerance(2);
  RightFrontAsDcMotor.setTargetPositionTolerance(2);
  RightRearAsDcMotor.setTargetPositionTolerance(2);
  LeftRearAsDcMotor.setTargetPositionTolerance(2);
  StopAndZeroDriveEnc();
  // Go from 0 to max acceleration in # secs stored in this variable
  maxAcceleration = 5;
  v_LF = LeftFrontAsDcMotor.getVelocity();
  v_RF = RightFrontAsDcMotor.getVelocity();
  v_RR = RightRearAsDcMotor.getVelocity();
  v_LR = LeftRearAsDcMotor.getVelocity();
  // We are putting the definitions here so they are accessible in functions
  lpos_LF = LeftFrontAsDcMotor.getCurrentPosition();
  lpos_RF = RightFrontAsDcMotor.getCurrentPosition();
  lpos_RR = RightRearAsDcMotor.getCurrentPosition();
  lpos_LR = LeftRearAsDcMotor.getCurrentPosition();
  diff_LF = 0;
  diff_RF = 0;
  diff_RR = 0;
  diff_LR = 0;
  // Last Direction
  // N = None/Stopped
  // F = Fwd
  // B = Back
  // L= Left
  // R = Right
  l_dir = 'N';
  // Max velocity of Neverrest 20 * 0.9 to leave room for adjustments
  NR20_maxvelocity = 2250;
  NR20_TicsPerInch = 49.3;
  // Witf fractional here to make it a double
  MoveDirInches('F', 0.1);
  telemetryAddTextData('Status', 'Init');
  telemetry.update();
  linearOpMode.waitForStart();
  el_Time = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  elapsedTimeAccess.reset(el_Time);
  t_Last = elapsedTimeAccess.getTime(el_Time);
  t_Current = elapsedTimeAccess.getTime(el_Time);
  t_LastTelemetry = elapsedTimeAccess.getTime(el_Time);
  diff_time = t_Current - t_Last;
  LastError = 'None';
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      t_Current = elapsedTimeAccess.getTime(el_Time);
      if (gamepad1.getDpadUp()) {
        MoveDirInches('F', 24);
      }
      if (gamepad1.getDpadDown()) {
        MoveDirInches('B', 24);
      }
      if (gamepad1.getDpadLeft()) {
        MoveDirInches('L', 24);
      }
      if (gamepad1.getDpadRight()) {
        MoveDirInches('R', 24);
      }
      Servo_RAsServo.setPosition(gamepad1.getLeftTrigger());
      // JS Drive is last
      Xdrive_onedirection();
      teleopR_Telemetry();
      t_Last = t_Current;
    }
  }
  lpos_RR = RightRearAsDcMotor.getCurrentPosition();
}
