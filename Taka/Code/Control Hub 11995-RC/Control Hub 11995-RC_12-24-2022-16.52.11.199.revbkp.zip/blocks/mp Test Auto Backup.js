// IDENTIFIERS_USED=LeftFrontAsDcMotor,LeftRearAsDcMotor,RightFrontAsDcMotor,RightRearAsDcMotor

var AutoTimer, NR20_MaxVelocity, NR20_PulsesPerInch, NRC40_MaxVelocity, NRC40_PulsesPerInch, NRC40_PulsesPerDeg, AutoDriveSpeed, v_AutoDrive, v_RF, v_LF, v_LR, v_RR, AutoMode, distance;

/**
 * Stop and reset encoders on drive
 */
function ResetDriveEncoders() {
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  LeftFrontAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
}

/**
 * Turn Off All Motors
 */
function TurnOffMotors() {
  LeftFrontAsDcMotor.setVelocity(0);
  RightFrontAsDcMotor.setVelocity(0);
  RightRearAsDcMotor.setVelocity(0);
  LeftRearAsDcMotor.setVelocity(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  NR20_MaxVelocity = 2700;
  NR20_PulsesPerInch = 10.61;
  // Same as NR40 as it uses same motor/encoder before the gearbox
  NRC40_MaxVelocity = 746.6;
  NRC40_PulsesPerInch = 22.1;
  // NRC40 does 7*40 = 280 pulses per deg so that gives 280/360 pulses per deg
  NRC40_PulsesPerDeg = 0.777777777778;
  // multiplier to get velocity in pps has to be <=1
  AutoDriveSpeed = 0.999;
  v_AutoDrive = AutoDriveSpeed * NRC40_MaxVelocity;
  LeftFrontAsDcMotor.setDualMode("RUN_USING_ENCODER", LeftRearAsDcMotor, "RUN_USING_ENCODER");
  RightFrontAsDcMotor.setDualMode("RUN_USING_ENCODER", RightRearAsDcMotor, "RUN_USING_ENCODER");
  LeftFrontAsDcMotor.setDirection("REVERSE");
  RightFrontAsDcMotor.setDirection("REVERSE");
  RightRearAsDcMotor.setDirection("REVERSE");
  LeftRearAsDcMotor.setDirection("REVERSE");
  LeftFrontAsDcMotor.setZeroPowerBehavior("BRAKE");
  RightFrontAsDcMotor.setZeroPowerBehavior("BRAKE");
  RightRearAsDcMotor.setZeroPowerBehavior("BRAKE");
  LeftRearAsDcMotor.setZeroPowerBehavior("BRAKE");
  // About +/- 1/6th inch
  LeftFrontAsDcMotor.setTargetPositionTolerance(2);
  RightFrontAsDcMotor.setTargetPositionTolerance(2);
  RightRearAsDcMotor.setTargetPositionTolerance(2);
  LeftRearAsDcMotor.setTargetPositionTolerance(2);
  TurnOffMotors();
  ResetDriveEncoders();
  v_RF = RightFrontAsDcMotor.getVelocity();
  v_LF = LeftFrontAsDcMotor.getVelocity();
  v_LR = LeftRearAsDcMotor.getVelocity();
  v_RR = RightRearAsDcMotor.getVelocity();
  AutoMode = 0;
  AutoTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  telemetryAddTextData('Status', 'Auto Init 2');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (AutoMode == 0) {
        ResetDriveEncoders();
        elapsedTimeAccess.reset(AutoTimer);
        AutoMode = 1;
      }
      if (AutoMode == 1) {
        telemetry.addNumericData('Auto Mode', AutoMode);
        telemetryAddTextData('AutoDescription', 'Move Fwd 12 in');
        telemetry.update();
        distance = NR20_PulsesPerInch * 12;
        LeftFrontAsDcMotor.setTargetPosition(distance);
        RightFrontAsDcMotor.setTargetPosition(-distance);
        RightRearAsDcMotor.setTargetPosition(-distance);
        LeftRearAsDcMotor.setTargetPosition(distance);
        LeftFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightRearAsDcMotor.setVelocity(v_AutoDrive);
        LeftRearAsDcMotor.setVelocity(v_AutoDrive);
        // Give motors a little time
        linearOpMode.sleep(250);
        // This way we ensure all motors are at destination
        while (LeftFrontAsDcMotor.isBusy() && RightFrontAsDcMotor.isBusy()) {
          linearOpMode.sleep(250);
        }
        while (RightRearAsDcMotor.isBusy() && LeftRearAsDcMotor.isBusy()) {
          linearOpMode.sleep(250);
        }
        ResetDriveEncoders();
        TurnOffMotors();
        AutoMode = 2;
      }
      if (AutoMode == 2) {
        telemetry.addNumericData('Auto Mode', AutoMode);
        telemetryAddTextData('AutoDescription', 'Move side ways 12 in');
        telemetry.update();
        ResetDriveEncoders();
        // Now lets move distance sideways
        distance = NR20_PulsesPerInch * 12;
        LeftFrontAsDcMotor.setTargetPosition(distance);
        RightFrontAsDcMotor.setTargetPosition(distance);
        RightRearAsDcMotor.setTargetPosition(-distance);
        LeftRearAsDcMotor.setTargetPosition(-distance);
        LeftFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightFrontAsDcMotor.setVelocity(v_AutoDrive);
        RightRearAsDcMotor.setVelocity(v_AutoDrive);
        LeftRearAsDcMotor.setVelocity(v_AutoDrive);
        // Give motors a little time
        linearOpMode.sleep(250);
        // This way we ensure all motors are at destination
        while (LeftFrontAsDcMotor.isBusy() && RightFrontAsDcMotor.isBusy()) {
          linearOpMode.sleep(250);
        }
        while (RightRearAsDcMotor.isBusy() && LeftRearAsDcMotor.isBusy()) {
          linearOpMode.sleep(250);
        }
        AutoMode = 3;
      }
    }
  }
}
