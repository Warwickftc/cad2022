// IDENTIFIERS_USED=imuAsBNO055IMU,LeftFrontAsDcMotor,LeftRearAsDcMotor

var IMU_Parameters, ElapsedTime, M1_Power, M2_Power, YawValue;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  LeftFrontAsDcMotor.setDirection("REVERSE");
  IMU_Parameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setSensorMode(IMU_Parameters, "IMU");
  imuAsBNO055IMU.initialize(IMU_Parameters);
  telemetryAddTextData('Status', 'IMU initialized');
  telemetry.update();
  linearOpMode.sleep(1000);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
  linearOpMode.waitForStart();
  ElapsedTime = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  M1_Power = 0.3;
  M2_Power = 0.3;
  LeftFrontAsDcMotor.setDualPower(M1_Power, LeftRearAsDcMotor, M2_Power);
  while (!(elapsedTimeAccess.getMilliseconds(ElapsedTime) >= 2000 || linearOpMode.isStopRequested())) {
    YawValue = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Yaw value', YawValue);
    if (YawValue < -5) {
      M1_Power = 0.25;
      M2_Power = 0.35;
    } else if (YawValue > 5) {
      M1_Power = 0.35;
      M2_Power = 0.25;
    } else {
      M1_Power = 0.3;
      M2_Power = 0.3;
    }
    telemetry.addNumericData('Motor 1 Power', M1_Power);
    telemetry.addNumericData('Motor 2 Power', M2_Power);
    LeftFrontAsDcMotor.setDualPower(M1_Power, LeftRearAsDcMotor, M2_Power);
    telemetry.update();
    linearOpMode.sleep(200);
  }
  LeftFrontAsDcMotor.setDualPower(0, LeftRearAsDcMotor, 0);
  linearOpMode.sleep(2000);
  M1_Power = 0.1;
  M2_Power = -0.1;
  while (!(YawValue <= -90 || linearOpMode.isStopRequested())) {
    LeftFrontAsDcMotor.setDualPower(M1_Power, LeftRearAsDcMotor, M2_Power);
    telemetry.addNumericData('Motor 1 Power', M1_Power);
    telemetry.addNumericData('Motor 2 Power', M2_Power);
    telemetry.addNumericData('Yaw value', YawValue);
    telemetry.update();
    linearOpMode.sleep(200);
    YawValue = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
  }
  LeftFrontAsDcMotor.setDualPower(0, LeftRearAsDcMotor, 0);
}

/**
 * Function that becomes true when gyro is calibrated and
 * reports calibration status to Driver Station in the meantime.
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}
