var i, recognition, forwardmsec, backwardmsec, moveleft, recognitions, index;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  front_rightAsDcMotor.setDirection("REVERSE");
  back_rightAsDcMotor.setDirection("REVERSE");
  vuforiaCurrentGameAccess.initialize_withWebcam("Webcam 1", '', false, false, "AXES", 0, 0, 0, 90, 0, 90, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.8, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(2.5, 16 / 9);
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    // Get a list of recognitions from TFOD.
    recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
    arm_servoAsServo.setPosition(0.94);
    linearOpMode.sleep(500);
    // If list is empty, inform the user. Otherwise, go
    // through list and display info for each recognition.
    if (recognitions.length == 0) {
      telemetryAddTextData('TFOD', 'No items detected.');
    } else {
      index = 0;
      // Iterate through list and call a function to
      // display info for each recognized object.
      for (var recognition_index in recognitions) {
        recognition = recognitions[recognition_index];
        displayInfo(index);
        index = index + 1;
      }
    }
    telemetry.update();
    linearOpMode.sleep(1000);
    index = 0;
    // If list is empty, inform the user. Otherwise, go
    // through list and display info for each recognition.
    if (recognitions.length == 0) {
      telemetryAddTextData('TFOD', 'No items detected.');
      telemetryAddTextData('Target Zone', 'A');
      forwardmsec = 2350;
      backwardmsec = 50;
      moveleft = false;
    } else {
      index = 0;
      // Iterate through list and call a function to
      // display info for each recognized object.
      for (var recognition_index2 in recognitions) {
        recognition = recognitions[recognition_index2];
        displayInfo(index);
        index = index + 1;
      }
    }
    telemetry.update();
    linearOpMode.sleep(500);
    pulleyAsDcMotor.setPower(0.15);
    linearOpMode.sleep(500);
    front_leftAsDcMotor.setDualPower(0.6, back_rightAsDcMotor, 0.6);
    back_leftAsDcMotor.setDualPower(0.6, front_rightAsDcMotor, 0.6);
    linearOpMode.sleep(forwardmsec);
    front_leftAsDcMotor.setDualPower(0, back_rightAsDcMotor, 0);
    back_leftAsDcMotor.setDualPower(0, front_rightAsDcMotor, 0);
    linearOpMode.sleep(100);
    if (moveleft == false) {
      linearOpMode.sleep(100);
    } else {
      front_leftAsDcMotor.setDualPower(-0.3, back_rightAsDcMotor, -0.3);
      back_leftAsDcMotor.setDualPower(0.3, front_rightAsDcMotor, 0.3);
      linearOpMode.sleep(1000);
      front_leftAsDcMotor.setDualPower(0, back_rightAsDcMotor, 0);
      back_leftAsDcMotor.setDualPower(0, front_rightAsDcMotor, 0);
      linearOpMode.sleep(100);
    }
    pulleyAsDcMotor.setPower(0);
    linearOpMode.sleep(750);
    arm_servoAsServo.setPosition(0.7);
    linearOpMode.sleep(750);
    front_leftAsDcMotor.setDualPower(-0.3, back_rightAsDcMotor, -0.3);
    back_leftAsDcMotor.setDualPower(-0.3, front_rightAsDcMotor, -0.3);
    linearOpMode.sleep(backwardmsec);
    front_leftAsDcMotor.setDualPower(0, back_rightAsDcMotor, 0);
    back_leftAsDcMotor.setDualPower(0, front_rightAsDcMotor, 0);
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Display info (using telemetry) for a recognized object.
 */
function displayInfo(i) {
  // Display the label and index number for the recognition.
  telemetryAddTextData('label ' + String(i), recognition.Label);
  // Display the location of the top left corner
  // of the detection boundary for the recognition
  telemetryAddTextData('Left, Top ' + String(i), String(recognition.Left) + String(', ' + String(recognition.Top)));
  // Display the location of the bottom right corner
  // of the detection boundary for the recognition
  telemetryAddTextData('Right, Bottom ' + String(i), String(recognition.Right) + String(', ' + String(recognition.Bottom)));
  if (recognition.Label == 'Single') {
    telemetryAddTextData('Target Zone', 'B');
    forwardmsec = 3000;
    backwardmsec = 750;
    moveleft = true;
  } else if (recognition.Label == 'Quad') {
    telemetryAddTextData('Target Zone', 'C');
    forwardmsec = 3750;
    backwardmsec = 2000;
    moveleft = false;
  } else {
    telemetryAddTextData('Target Zone', 'UNKNOWN');
  }
}
